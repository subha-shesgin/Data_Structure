#include <iostream>
#include <vector>
using namespace std;

// Recursive function to generate subsets
void generateSubsets(vector<int>& nums, vector<int>& subset, int index, vector<vector<int>>& result) {
    // Add the current subset to the result
    result.push_back(subset);

    // Iterate through remaining elements
    for (int i = index; i < nums.size(); i++) {
        subset.push_back(nums[i]);  // Include nums[i]
        generateSubsets(nums, subset, i + 1, result); // Recursive call
        subset.pop_back();  // Backtrack (Remove last added element)
    }
}

vector<vector<int>> subsets(vector<int>& nums) {
    vector<vector<int>> result;  // Store all subsets
    vector<int> subset;  // Temporary subset storage
    generateSubsets(nums, subset, 0, result);
    return result;
}

int main() {
    vector<int> nums = {1, 2, 3};  // Input set

    vector<vector<int>> result = subsets(nums);  // Generate subsets

    // Print output in required format
    cout << "[";
    for (int i = 0; i < result.size(); i++) {
        cout << "[";
        for (int j = 0; j < result[i].size(); j++) {
            cout << result[i][j];
            if (j < result[i].size() - 1) cout << ","; // Comma between elements
        }
        cout << "]";
        if (i < result.size() - 1) cout << ","; // Comma between subsets
    }
    cout << "]" << endl;

    return 0;
}
